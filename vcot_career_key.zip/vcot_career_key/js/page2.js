function calculateTotal_R2() {
    var selectElements = document.querySelectorAll('.calculate_R2');
    var totalElement = document.getElementsByName('R_2')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_I2() {
    var selectElements = document.querySelectorAll('.calculate_I2');
    var totalElement = document.getElementsByName('I_2')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_A2() {
    var selectElements = document.querySelectorAll('.calculate_A2');
    var totalElement = document.getElementsByName('A_2')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_S2() {
    var selectElements = document.querySelectorAll('.calculate_S2');
    var totalElement = document.getElementsByName('S_2')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_E2() {
    var selectElements = document.querySelectorAll('.calculate_E2');
    var totalElement = document.getElementsByName('E_2')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_C2() {
    var selectElements = document.querySelectorAll('.calculate_C2');
    var totalElement = document.getElementsByName('C_2')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

