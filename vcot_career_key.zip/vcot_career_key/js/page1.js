
function calculateTotal_R1() {
    var selectElements = document.querySelectorAll('.calculate_R1');
    var totalElement = document.getElementsByName('R_1')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_I1() {
    var selectElements = document.querySelectorAll('.calculate_I1');
    var totalElement = document.getElementsByName('I_1')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_A1() {
    var selectElements = document.querySelectorAll('.calculate_A1');
    var totalElement = document.getElementsByName('A_1')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_S1() {
    var selectElements = document.querySelectorAll('.calculate_S1');
    var totalElement = document.getElementsByName('S_1')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_E1() {
    var selectElements = document.querySelectorAll('.calculate_E1');
    var totalElement = document.getElementsByName('E_1')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

function calculateTotal_C1() {
    var selectElements = document.querySelectorAll('.calculate_C1');
    var totalElement = document.getElementsByName('C_1')[0];

    var total = 0;
    selectElements.forEach(function(select) {
        total += parseInt(select.value);
    });

    totalElement.value = total;
}

