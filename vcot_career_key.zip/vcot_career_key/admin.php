<?php
session_start();

// Check if the user is authenticated
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    // Redirect to login page or show an access denied message
    header('Location: login.php');
    exit();
}

// Check if the logout form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    // Unset all session variables
    session_unset();

    // Destroy the session
    session_destroy();

    // Redirect to the login page after logout
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/admin.css">
    <link rel="stylesheet" href="./css/footer.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <title>Key for Job | Admin</title>
</head>

<body>
<script>
        $(document).ready(function() {
            $('.nav-links a').click(function() {
                // Remove 'active' class from all links
                $('.nav-links a').removeClass('active');

                // Add 'active' class to the clicked link
                $(this).addClass('active');

                // Smoothly scroll to the target section
                var targetSection = $(this).attr('href');
                $('html, body').animate({
                    scrollTop: $(targetSection).offset().top
                }, 1000); // Adjust the duration as needed
            });
        });
    </script>
<div class="site-navigation">
        <nav>
               <div class="nav-content">
                 <div class="logo">
                   <a class="navbar-brand" href="https://www.vcot.lk">
                       <img src="./images/logo.png" alt="" class="img-fluid">
                   </a>
                 </div>
                 <ul class="nav-links">
                 <li><a href="index.html">Home</a></li>
                   <li><a href="#">About</a></li>
                   <li><a href="#">Services</a></li>
                   <li><a href="#footer">Contact</a></li>
                 </ul>
               
               
                <div class="login-button">
                     <form method="post" action="">
                     <button type="submit" name="logout" class="bttn bttn-primary">Logout</button>
                     </form>
                 </div>
                </div>
    </div>
           </div>
           </nav> 
           </div>
    <main>
    <div class="Heading">
        <h1> மாணவர்களின் சேகரிக்கப்பட்ட தரவுகள்</h1>
    </div>
    <div class="container">
        <?php

        $con = new mysqli('localhost', 'root', 'Ex6826679#', 'script');

        // Check the database connection
        if ($con->connect_error) {
            die("Connection failed: " . $con->connect_error);
        }

        // Set the number of records per page
        $recordsPerPage = 10;

        // Get the current page number from the URL, default to 1 if not set
        $currentPage = isset($_GET['page']) ? $_GET['page'] : 1;

        // Calculate the offset for the SQL query
        $offset = ($currentPage - 1) * $recordsPerPage;

        // Fetch only the required rows for the current page
        $query = "SELECT * FROM `marks` LIMIT $offset, $recordsPerPage";
        $result = mysqli_query($con, $query);

        // Check if the query was successful
        if ($result) {
            $sn = $offset + 1;
            echo '<table class="custom-table">';
            echo '<thead>
                    <tr>
                        <th>No.</th>
                        <th>User Id</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Total_R</th>
                        <th>Total_I</th>
                        <th>Total_A</th>
                        <th>Total_S</th>
                        <th>Total_E</th>
                        <th>Total_C</th>
                    </tr>
                </thead>';
            echo '<tbody>';

            // Loop through each row in the result set
            while ($row = mysqli_fetch_assoc($result)) {
                // Fetch user details from the 'users' table based on 'id'
                $userId = $row['user_id'];
                $userQuery = "SELECT name, age FROM `users` WHERE id = '$userId'";
                $userResult = mysqli_query($con, $userQuery);

                if ($userResult && $userData = mysqli_fetch_assoc($userResult)) {
                    echo '<tr>';
                    echo '<td>' . $sn++ . '</td>';
                    echo '<td>' . $row['user_id'] . '</td>';
                    echo '<td>' . $userData['name'] . '</td>';
                    echo '<td>' . $userData['age'] . '</td>';
                    echo '<td>' . $row['total_R'] . '</td>';
                    echo '<td>' . $row['total_I'] . '</td>';
                    echo '<td>' . $row['total_A'] . '</td>';
                    echo '<td>' . $row['total_S'] . '</td>';
                    echo '<td>' . $row['total_E'] . '</td>';
                    echo '<td>' . $row['total_C'] . '</td>';
                    echo '</tr>';
                }
            }

            echo '</tbody>';
            echo '</table>';
            echo '</div>';

            // Pagination buttons
            $totalRecordsQuery = "SELECT COUNT(*) as totalRecords FROM `marks`";
            $totalRecordsResult = mysqli_query($con, $totalRecordsQuery);
            $totalRecords = mysqli_fetch_assoc($totalRecordsResult)['totalRecords'];
            $totalPages = ceil($totalRecords / $recordsPerPage);

            echo '<div class="pagination">';
            if ($currentPage > 1) {
                echo '<button class= "previous" onclick="location.href=\'?page=' . ($currentPage - 1) . '\'">Previous</button>';
            }

            if ($currentPage < $totalPages) {
                echo '<button class= "next" onclick="location.href=\'?page=' . ($currentPage + 1) . '\'">Next</button>';
            }

            echo '</div>';
        } else {
            trigger_error(mysqli_error($con), E_USER_ERROR);
        }

        // Close the database connection
        $con->close();
        ?>
        </div>
   </main>
   <footer class="contain" id="footer">
    <div class="footer-content">
       <div class="contact-details ">
        <a href="https://vcot.lk/"><img src="./images/logo.png" class="big-logo" alt="VCOT Logo"></a>
        <p class="description">The Vivekananda College of Technology was established as a charity organization in 2012 by social service activist Mr. K. Satguneswaran, in order to facilitate marginalized youth to have access and acquire basic computer knowledge to face the community.</p>
        </div>
        <div class="footer-content"> 
            <div class="contact-details">
                <h5 class="widget-title">Batticaloa South</h5>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div>+94 65 312 5555</div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div><a href="https://wa.me/94755600666" target="_blank">+94 75 079 0790</a></div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>Puthukkudiyiruppu</div>
                </div>
            </div>
            <div class="contact-details">
                <h5 class="widget-title">Batticaloa North</h5>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div>+94 65 312 5555</div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div><a href="https://wa.me/94755600666" target="_blank">+94 75 079 0790</a></div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>Kommathurai</div>
                </div>
            </div>
            <div class="contact-details">
                <h5 class="widget-title">Mulaitivu</h5>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div>+94 65 312 5555</div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div><a href="https://wa.me/94755600666" target="_blank">+94 75 079 0790</a></div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>Puthukkudiyiruppu</div>
                </div>
            </div>
        </div>
        <a href="https://wa.me/94755600666" class="whatsapp-float" target="_blank" rel="noopener noreferrer">
            <i class="fab fa-whatsapp"></i>
        </a>
        
    </div>
    
    <div class="footer-btm">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-12">
                    <div class="copyright text-lg-left">
                        <p>© Copyright 2012 - 2024 <a href="https://vcot.lk">Vivekananda College of Technology</a>. All Rights Reserved. Site by <a href="https://amirda.lk" target="_blank">Amirda</a></p>
                    </div>
                </div>
            </div>
        
    </div>
</footer>
</body>

</html>
