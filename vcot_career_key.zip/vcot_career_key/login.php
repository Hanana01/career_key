<?php
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Replace with your authentication logic
    if ($username === 'admin' && $password === 'amirda_admin123') {
        $_SESSION['authenticated'] = true;
        header('Location: admin.php');
        exit();
    } else {
        echo  '<script>alert("Incorrect username or password. Please try again.");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/login.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <title>Career Guidance-Admin Login</title>
</head>
<body>
    <h1>Welcome to Career Key!</h1>
    <main>
        <!-- Your login form goes here -->
        <div class="left-column">
            <img src="./images/key.png" class="key">
        </div>
        <div class="right-column">
            <div class="login-form">
                <form method="post" action="">

                    <div class="input_box">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                    <div class="icon"><i class="fas fa-user"></i></div>
                    </div>
                    
                    <div class="input_box">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    <div class="icon"><i class="fas fa-lock"></i></div>
                    </div>
                    
                    
                    <button type="submit">Login</button>
                </form>
            </div>
        </div>
        <!-- Display error message if authentication fails -->
        <?php if (isset($error)) : ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
    </main>
</body>
</html>
