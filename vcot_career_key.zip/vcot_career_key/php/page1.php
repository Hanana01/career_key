<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $R_1 = $_POST['R_1'];
    $I_1 = $_POST['I_1'];
    $A_1 = $_POST['A_1'];
    $S_1 = $_POST['S_1'];
    $E_1 = $_POST['E_1'];
    $C_1 = $_POST['C_1'];

    // Check if all values are zero
    if ($R_1 == 0 && $I_1 == 0 && $A_1 == 0 && $S_1 == 0 && $E_1 == 0 && $C_1 == 0) {
        echo '<script>alert("All values are zero. Please enter some values.");';
        echo 'window.location.href = "../page1.html";</script>';
    } else {
        // Store values in session
        $_SESSION['R_1'] = $R_1;
        $_SESSION['I_1'] = $I_1;
        $_SESSION['A_1'] = $A_1;
        $_SESSION['S_1'] = $S_1;
        $_SESSION['E_1'] = $E_1;
        $_SESSION['C_1'] = $C_1;

        // Redirect to the next page
        echo '<script>window.location.href = "../page2.html";</script>';
        exit();
    }
}
?>
