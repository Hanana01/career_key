<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/page3.css">
    <link rel="stylesheet" href="./css/footer.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <title>Key for Job | Unlock Your Career Potential</title>
</head>
<body>
<div class="site-navigation">
        <nav>
               <div class="nav-content">
                 <div class="logo">
                   <a class="navbar-brand" href="https://www.vcot.lk">
                       <img src="./images/logo.png" alt="" class="img-fluid">
                   </a>
                 </div>
                 <ul class="nav-links">
                   <li><a href="index.html" class="active">Home</a></li>
                   <li><a href="#">About</a></li>
                   <li><a href="#">Services</a></li>
                   <li><a href="#footer">Contact</a></li>
                 </ul>
               
               <div class="login-button">
                   <a href="login.php" class="bttn bttn-primary">Login</a>
                 </div>
           </div>
           </nav> 
           </div>
<main>
    <div class="container">
        <p> தற்பொழுது பக்கம் 2 மற்றும் பக்கம் 3 இல் நீங்கள் குறிப்பிட்ட புள்ளிகளினை ஆங்கில எழுத்துக்களின் அடிப்படையில் கீழே காட்டப்பட்ட அட்டவணையில் காணலாம்
        </p>   
    </div>
    
    <table class="custom-table">
        <tr>
            <th>ஆங்கில எழுத்து</th>
            <th>R</th>
            <th>I</th>
            <th>A</th>
            <th>S</th>
            <th>E</th>
            <th>C</th>
        </tr>
        <?php
        $con = new mysqli('localhost', 'root', 'Ex6826679#', 'script');

        // Check the database connection
        if ($con->connect_error) {
            die("Connection failed: " . $con->connect_error);
        }

        // Fetch the last row from the marks table
        $lastRowQuery = "SELECT * FROM `marks` ORDER BY id DESC LIMIT 1";
        $lastRowResult = mysqli_query($con, $lastRowQuery);

        if ($lastRowResult && $lastRow = mysqli_fetch_assoc($lastRowResult)) {
            echo '<tr>';
            echo '<td>பக்கம் 2</td>';
            echo '<td>' . $lastRow['R_1'] . '</td>';
            echo '<td>' . $lastRow['I_1'] . '</td>';
            echo '<td>' . $lastRow['A_1'] . '</td>';
            echo '<td>' . $lastRow['S_1'] . '</td>';
            echo '<td>' . $lastRow['E_1'] . '</td>';
            echo '<td>' . $lastRow['C_1'] . '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<td>பக்கம் 3</td>';
            // You can populate the values for page 3 here based on your requirements
            echo '<td>' . $lastRow['R_2'] . '</td>';
            echo '<td>' . $lastRow['I_2'] . '</td>';
            echo '<td>' . $lastRow['A_2'] . '</td>';
            echo '<td>' . $lastRow['S_2'] . '</td>';
            echo '<td>' . $lastRow['E_2'] . '</td>';
            echo '<td>' . $lastRow['C_2'] . '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<td><b>மொத்தம்</b></td>';
            echo '<td>' . $lastRow['total_R'] . '</td>';
            echo '<td>' . $lastRow['total_I'] . '</td>';
            echo '<td>' . $lastRow['total_A'] . '</td>';
            echo '<td>' . $lastRow['total_S'] . '</td>';
            echo '<td>' . $lastRow['total_E'] . '</td>';
            echo '<td>' . $lastRow['total_C'] . '</td>';
            echo '</tr>';

            $data = array(
                'total_R' => $lastRow['total_R'],
                'total_I' => $lastRow['total_I'],
                'total_A' => $lastRow['total_A'],
                'total_S' => $lastRow['total_S'],
                'total_E' => $lastRow['total_E'],
                'total_C' => $lastRow['total_C']
            );
        } else {
            echo '<tr><td colspan="7">No data available</td></tr>';
        }
    ?>
    </table>

    <h2>உங்கள் தொழிலுக்கான திறவுகோல் வரைபு</h2>   
    <div class="graph-container">
    <canvas id="myChart"></canvas>
    </div>
    
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Use the PHP data directly
        var data = <?php echo json_encode($data); ?>;
    
        // Process data and generate graph using Chart.js
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['total_R', 'total_I', 'total_A', 'total_S', 'total_E', 'total_C'],
                datasets: [{
                    label: 'Scores',
                    data: [data.total_R, data.total_I, data.total_A, data.total_S, data.total_E, data.total_C],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 36, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>


</main>
<footer class="contain" id="footer">
    <div class="footer-content">
       <div class="contact-details ">
        <a href="https://vcot.lk/"><img src="./images/logo.png" class="big-logo" alt="VCOT Logo"></a>
        <p class="description">The Vivekananda College of Technology was established as a charity organization in 2012 by social service activist Mr. K. Satguneswaran, in order to facilitate marginalized youth to have access and acquire basic computer knowledge to face the community.</p>
        </div>
        <div class="footer-content"> 
            <div class="contact-details">
                <h5 class="widget-title">Batticaloa South</h5>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div>+94 65 312 5555</div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div><a href="https://wa.me/94755600666" target="_blank">+94 75 079 0790</a></div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>Puthukkudiyiruppu</div>
                </div>
            </div>
            <div class="contact-details">
                <h5 class="widget-title">Batticaloa North</h5>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div>+94 65 312 5555</div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div><a href="https://wa.me/94755600666" target="_blank">+94 75 079 0790</a></div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>Kommathurai</div>
                </div>
            </div>
            <div class="contact-details">
                <h5 class="widget-title">Mulaitivu</h5>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div>+94 65 312 5555</div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-phone"></i>
                    <div><a href="https://wa.me/94755600666" target="_blank">+94 75 079 0790</a></div>
                </div>
                <div class="contact-info">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>Puthukkudiyiruppu</div>
                </div>
            </div>
        </div>
      
    </div>
    
    <div class="footer-btm">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-12">
                    <div class="copyright text-lg-left">
                        <p>© Copyright 2012 - 2024 <a href="https://vcot.lk">Vivekananda College of Technology</a>. All Rights Reserved. Site by <a href="https://amirda.lk" target="_blank">Amirda</a></p>
                    </div>
                </div>
            </div>
        
    </div>
</footer>  
</body>
</html>
