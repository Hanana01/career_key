<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
    $R_2 = $_POST['R_2'];
    $I_2 = $_POST['I_2'];
    $A_2 = $_POST['A_2'];
    $S_2 = $_POST['S_2'];
    $E_2 = $_POST['E_2'];
    $C_2 = $_POST['C_2'];

    // Check if any of the values are zero
    if ($R_2 == 0 && $I_2 == 0 && $A_2 == 0 && $S_2 == 0 && $E_2 == 0 && $C_2 == 0) {
        echo '<script>alert("All values are zero. Please enter some values.");';
        echo 'window.location.href = "../page2.html";</script>';
    } else {
        $lastInsertedId = $_SESSION['lastInsertedId'];
        $R_1 = $_SESSION['R_1'];
        $I_1 = $_SESSION['I_1'];
        $A_1 = $_SESSION['A_1'];
        $S_1 = $_SESSION['S_1'];
        $E_1 = $_SESSION['E_1'];
        $C_1 = $_SESSION['C_1'];

        $sum_R = $R_1 + $R_2;
        $sum_I = $I_1 + $I_2;
        $sum_A = $A_1 + $A_2;
        $sum_S = $S_1 + $S_2;
        $sum_E = $E_1 + $E_2;
        $sum_C = $C_1 + $C_2;


        $con = new mysqli('localhost', 'root', 'Ex6826679#', 'script');

        if ($con) {
            $sql = "INSERT INTO `marks` (user_id, R_1, I_1, A_1, S_1, E_1, C_1, R_2, I_2, A_2, S_2, E_2, C_2, total_R, total_I, total_A, total_S, total_E, total_C) 
            VALUES ('$lastInsertedId', '$R_1', '$I_1', '$A_1', '$S_1', '$E_1', '$C_1', '$R_2', '$I_2', '$A_2', '$S_2', '$E_2', '$C_2', '$sum_R', '$sum_I', '$sum_A', '$sum_S', '$sum_E', '$sum_C')";

            $result = mysqli_query($con, $sql);

            if ($result) {
                echo '<script>alert("Marks inserted successfully."); window.location.href = "../php/page3.php";</script>';
            } else {
                die(mysqli_error($con));
            }
        } else {
            die(mysqli_error($con));
        }
    }
}
?>


