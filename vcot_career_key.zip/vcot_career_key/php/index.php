<?php

session_start();

if($_SERVER['REQUEST_METHOD']=='POST') {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $currentDate = date('Y-m-d');

// Validation for name and age
if ((!is_numeric($age) || $age <= 0 || $age >= 100) || (!preg_match("/^[a-zA-Z][a-zA-Z. ]*$/", $name))) {
    echo '<script>alert("Invalid name or age. Please check your input.");</script>';
    echo '<script>history.back();</script>';
    exit;
}


$con = new mysqli ('localhost', 'root', 'Ex6826679#', 'script');

if($con) {
   $sql = "insert into `users` ( name, date, age ) values ('$name', '$currentDate', '$age')";
   $result = mysqli_query ($con, $sql);
   
   if ($result){

    $lastInsertedId = mysqli_insert_id($con);

    $_SESSION['lastInsertedId'] = $lastInsertedId;

    echo '<script>window.location.href = "../page1.html";</script>';
    
   } else {
    die (mysqli_error($con));
   }

} else {
    die (mysqli_error($con));
}

}
?>


